<template>
    <h1>Welcome to Laravel 11 + Vue (Inertia.js)</h1>
</template>
